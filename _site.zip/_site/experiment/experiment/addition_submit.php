<?php
  echo $_GET['number1']+$_GET['number2'];
  echo "<br><br>";
  print_r($_POST); 
?>
