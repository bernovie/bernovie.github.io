<!DOCTYPE HTML>
<html>
<head>
</head>
<body>
<form action="contact_submit.php" method="post">
	Name: <input type="text" name="name"/><br>
	Email: <input type="text" name="email"/><br>
	Phone: <input type="text" name="phone"/><br>
	<input type="submit" name="submit_button">
</form>
<?php

?>
</body>
</html>
