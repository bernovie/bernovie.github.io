<?php
	echo "Name: ".$_POST["name"]."<br>";
	echo "Email: ".$_POST["email"]."<br>";
	echo "Phone: ".$_POST["phone"]."<br>";
?>
